/**
 * 可以从cfd提现任意金额抓包
 * url: https://m.jingxi.com/jxbfd/user/CashOut
 * 从url中找参数的值
 */
let Jxtoken = [
  {
    strPgUUNum: "",
    strPgtimestamp: "",
    strPhoneID: ""
  },
  {
    strPgUUNum: "",
    strPgtimestamp: "",
    strPhoneID: ""
  },
  {
    strPgUUNum: "",
    strPgtimestamp: "",
    strPhoneID: ""
  },
]

export default Jxtoken