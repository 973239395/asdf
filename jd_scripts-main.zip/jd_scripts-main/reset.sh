git reset --hard $1
git push origin HEAD --force
